local QBCore = exports['qb-core']:GetCoreObject()
local robberyActive = {}
local robberyCooldowns = {}

print('^2[thebest-robbery] Server script loaded with strict weapon requirement^0')

-- Get police count
function GetPoliceCount()
    local count = 0
    local players = QBCore.Functions.GetPlayers()
    
    for i = 1, #players do
        local player = QBCore.Functions.GetPlayer(players[i])
        if player and player.PlayerData.job.name == Config.PoliceJobName then
            count = count + 1
        end
    end
    
    return count
end

-- Check if can start robbery
function CanStartRobbery(src, marketId)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false, "Player not found" end
    
    local market = Config.Markets[marketId]
    if not market then return false, "Invalid market" end
    
    -- Check if already being robbed
    if robberyActive[marketId] then
        return false, "Already being robbed"
    end
    
    -- Check cooldown
    if robberyCooldowns[marketId] then
        local timeLeft = (robberyCooldowns[marketId] + Config.Cooldown) - os.time()
        if timeLeft > 0 then
            local minutes = math.floor(timeLeft / 60)
            local seconds = math.floor(timeLeft % 60)
            return false, "Recently robbed. Wait " .. minutes .. "m " .. seconds .. "s"
        end
    end
    
    -- Check police requirement
    if not Config.Debug and GetPoliceCount() < Config.MinCops then
        return false, "Need " .. Config.MinCops .. " police online"
    end
    
    return true, nil
end

-- Start Robbery (when ALT key pressed first time)
RegisterServerEvent('thebest-robbery:startRobbery')
AddEventHandler('thebest-robbery:startRobbery', function(marketId)
    local src = source
    
    local canRob, errorMsg = CanStartRobbery(src, marketId)
    if not canRob then
        TriggerClientEvent('thebest-robbery:notify', src, errorMsg, "error")
        return
    end
    
    local market = Config.Markets[marketId]
    if not market then return end
    
    -- Mark as active
    robberyActive[marketId] = src
    
    -- Start client robbery
    TriggerClientEvent('thebest-robbery:startClientRobbery', src, marketId)
    
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        print('^3[thebest-robbery] Robbery started at: ' .. market.name .. 
              ' by ' .. Player.PlayerData.charinfo.firstname .. '^0')
    end
end)

-- Cancel Robbery (when player leaves zone or loses weapon)
RegisterServerEvent('thebest-robbery:cancelRobbery')
AddEventHandler('thebest-robbery:cancelRobbery', function(marketId)
    local src = source
    
    if robberyActive[marketId] == src then
        robberyActive[marketId] = nil
        print('^3[thebest-robbery] Robbery cancelled at market ' .. marketId .. ' by player ' .. src .. '^0')
    end
end)

-- Give Money (when player picks up money)
RegisterServerEvent('thebest-robbery:giveMoney')
AddEventHandler('thebest-robbery:giveMoney', function(marketId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player or robberyActive[marketId] ~= src then 
        TriggerClientEvent('thebest-robbery:notify', src, "You didn't start this robbery", "error")
        return 
    end
    
    local market = Config.Markets[marketId]
    if not market then return end
    
    -- Give fixed $4500 to player
    Player.Functions.AddMoney('cash', Config.MoneyAmount)
    
    -- Set cooldown
    robberyCooldowns[marketId] = os.time()
    robberyActive[marketId] = nil
    
    -- Notify player
    TriggerClientEvent('thebest-robbery:moneyReceived', src, Config.MoneyAmount)
    
    print('^3[thebest-robbery] ' .. Player.PlayerData.charinfo.firstname .. 
          ' received $' .. Config.MoneyAmount .. ' from ' .. market.name .. '^0')
end)

-- Alert Police
RegisterServerEvent('thebest-robbery:alertPolice')
AddEventHandler('thebest-robbery:alertPolice', function(coords, storeName)
    local players = QBCore.Functions.GetPlayers()
    
    for i = 1, #players do
        local player = QBCore.Functions.GetPlayer(players[i])
        if player and player.PlayerData.job.name == Config.PoliceJobName then
            TriggerClientEvent('thebest-robbery:policeAlert', players[i], coords, storeName)
        end
    end
    
    print('^3[thebest-robbery] Police alerted: ' .. storeName .. '^0')
end)

-- Admin Commands
if Config.TestMode then
    QBCore.Commands.Add("robstatus", "Check robbery status", {}, false, function(source)
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        
        if not Player then return end
        
        TriggerClientEvent('thebest-robbery:notify', src, "=== ROBBERY STATUS ===", "primary")
        
        for i, market in ipairs(Config.Markets) do
            local status = robberyActive[i] and "^1ROBBING^0" or "^2READY^0"
            local cooldown = ""
            
            if robberyCooldowns[i] then
                local timeLeft = (robberyCooldowns[i] + Config.Cooldown) - os.time()
                if timeLeft > 0 then
                    local mins = math.floor(timeLeft / 60)
                    local secs = math.floor(timeLeft % 60)
                    cooldown = " (Cooldown: " .. mins .. "m " .. secs .. "s)"
                end
            end
            
            TriggerClientEvent('thebest-robbery:notify', src, 
                market.name .. ": " .. status .. cooldown, "primary")
        end
        
        TriggerClientEvent('thebest-robbery:notify', src, 
            "Police online: " .. GetPoliceCount() .. "/" .. Config.MinCops, "primary")
    end)
    
    QBCore.Commands.Add("forcerob", "Force start robbery", {{name="id", help="Market ID (1-15)"}}, false, function(source, args)
        local src = source
        local marketId = tonumber(args[1]) or 1
        
        if Config.Markets[marketId] then
            robberyActive[marketId] = src
            TriggerClientEvent('thebest-robbery:startClientRobbery', src, marketId)
            TriggerClientEvent('thebest-robbery:notify', src, "Forced robbery started at " .. Config.Markets[marketId].name, "success")
        end
    end)
    
    QBCore.Commands.Add("givemoney", "Give money directly", {}, false, function(source)
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            Player.Functions.AddMoney('cash', Config.MoneyAmount)
            TriggerClientEvent('thebest-robbery:notify', src, "Given $" .. Config.MoneyAmount .. " directly", "success")
        end
    end)
    
    QBCore.Commands.Add("resetrobbery", "Reset all robberies", {}, false, function(source)
        local src = source
        robberyActive = {}
        robberyCooldowns = {}
        TriggerClientEvent('thebest-robbery:notify', src, "All 15 market robberies reset", "success")
        print('^3[thebest-robbery] All robberies reset by Player ID: ' .. src .. '^0')
    end)
    
    QBCore.Commands.Add("checkcops", "Check police online", {}, false, function(source)
        local src = source
        local count = GetPoliceCount()
        TriggerClientEvent('thebest-robbery:notify', src, "Police online: " .. count .. " (Required: " .. Config.MinCops .. ")", "primary")
    end)
    
    QBCore.Commands.Add("marketinfo", "Get market info", {{name="id", help="Market ID"}}, false, function(source, args)
        local src = source
        local marketId = tonumber(args[1]) or 1
        local market = Config.Markets[marketId]
        
        if market then
            TriggerClientEvent('thebest-robbery:notify', src, "Market " .. marketId .. ": " .. market.name, "info")
            TriggerClientEvent('thebest-robbery:notify', src, "Cash Spot: " .. tostring(market.cashSpot), "info")
            TriggerClientEvent('thebest-robbery:notify', src, "Money Drop: " .. tostring(market.moneyDropSpot), "info")
        end
    end)
    
    QBCore.Commands.Add("bypassweapon", "Bypass weapon check (Admin)", {}, false, function(source)
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        if Player and Player.PlayerData.job.name == 'admin' then
            TriggerClientEvent('thebest-robbery:notify', src, "Weapon check bypassed for testing", "warning")
            -- This would be implemented in a real system
        end
    end)
end