Config = {}

-- Debug Mode
Config.Debug = false
Config.TestMode = true

-- Robbery Settings
Config.WaitTime = 120  -- 2 minutes waiting time
Config.Cooldown = 300  -- 5 minutes between robberies
Config.MoneyAmount = 4500  -- Fixed $4500 amount
Config.MinCops = 2  -- Need 2 police online

-- Weapon Settings
Config.RequireWeapon = true  -- MUST have weapon to start
Config.WeaponCheckType = "any"  -- "any" = any gun, "specific" = specific weapons
Config.AllowedWeapons = {  -- Only these weapons allowed if type is "specific"
    "weapon_pistol",
    "weapon_combatpistol", 
    "weapon_pistol50",
    "weapon_snspistol",
    "weapon_heavypistol",
    "weapon_vintagepistol",
    "weapon_microsmg",
    "weapon_smg",
    "weapon_assaultsmg",
    "weapon_combatpdw"
}

-- Zone Settings
Config.MarketZoneRadius = 15.0
Config.InteractionDistance = 2.0
Config.InteractionKey = 19  -- LEFT ALT key (19)

-- Money Drop Settings
Config.MoneyModel = "prop_anim_cash_pile_01"
Config.MoneyPickupDistance = 1.5
Config.MoneyPickupKey = 38  -- E key

-- ALL MARKET LOCATIONS (15 Markets)
Config.Markets = {
    -- 24/7 Stores
    {
        id = 1,
        name = "24/7 Supermarket",
        zoneCenter = vector3(24.5, -1347.3, 29.5),
        cashSpot = vector3(24.8, -1347.3, 29.5),
        pedCoords = vector3(24.5, -1347.3, 29.5),
        moneyDropSpot = vector3(24.0, -1348.0, 29.4),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    {
        id = 2,
        name = "24/7 Mirror Park",
        zoneCenter = vector3(1165.0, -324.5, 69.2),
        cashSpot = vector3(1164.7, -324.5, 69.2),
        pedCoords = vector3(1165.0, -324.5, 69.2),
        moneyDropSpot = vector3(1164.2, -325.0, 69.1),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    {
        id = 3,
        name = "24/7 Strawberry",
        zoneCenter = vector3(1735.0, 6420.8, 35.0),
        cashSpot = vector3(1734.7, 6420.8, 35.0),
        pedCoords = vector3(1735.0, 6420.8, 35.0),
        moneyDropSpot = vector3(1734.2, 6421.3, 34.9),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    {
        id = 4,
        name = "24/7 Great Ocean",
        zoneCenter = vector3(-3039.5, 585.9, 7.9),
        cashSpot = vector3(-3039.2, 585.9, 7.9),
        pedCoords = vector3(-3039.5, 585.9, 7.9),
        moneyDropSpot = vector3(-3040.0, 586.5, 7.8),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    {
        id = 5,
        name = "24/7 Palomino",
        zoneCenter = vector3(2556.8, 382.2, 108.6),
        cashSpot = vector3(2556.5, 382.2, 108.6),
        pedCoords = vector3(2556.8, 382.2, 108.6),
        moneyDropSpot = vector3(2556.0, 382.7, 108.5),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    
    -- LTD Gasoline Stores
    {
        id = 6,
        name = "LTD Gasoline",
        zoneCenter = vector3(-47.0, -1758.5, 29.4),
        cashSpot = vector3(-46.7, -1758.5, 29.4),
        pedCoords = vector3(-47.0, -1758.5, 29.4),
        moneyDropSpot = vector3(-47.5, -1759.0, 29.3),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    {
        id = 7,
        name = "LTD Mirror Park",
        zoneCenter = vector3(1163.4, -323.8, 69.2),
        cashSpot = vector3(1163.1, -323.8, 69.2),
        pedCoords = vector3(1163.4, -323.8, 69.2),
        moneyDropSpot = vector3(1162.6, -324.3, 69.1),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    {
        id = 8,
        name = "LTD Davis",
        zoneCenter = vector3(-41.9, -1748.1, 29.4),
        cashSpot = vector3(-41.6, -1748.1, 29.4),
        pedCoords = vector3(-41.9, -1748.1, 29.4),
        moneyDropSpot = vector3(-42.4, -1748.6, 29.3),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    
    -- Rob's Liquor Stores
    {
        id = 9,
        name = "Rob's Liquor",
        zoneCenter = vector3(1135.0, -982.0, 46.4),
        cashSpot = vector3(1134.7, -982.0, 46.4),
        pedCoords = vector3(1135.0, -982.0, 46.4),
        moneyDropSpot = vector3(1134.2, -982.5, 46.3),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    {
        id = 10,
        name = "Rob's Liquor Sandy",
        zoneCenter = vector3(1392.9, 3606.6, 34.9),
        cashSpot = vector3(1392.6, 3606.6, 34.9),
        pedCoords = vector3(1392.9, 3606.6, 34.9),
        moneyDropSpot = vector3(1392.1, 3607.1, 34.8),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    
    -- Other Stores
    {
        id = 11,
        name = "Discount Store",
        zoneCenter = vector3(378.1, 333.0, 103.6),
        cashSpot = vector3(377.8, 333.0, 103.6),
        pedCoords = vector3(378.1, 333.0, 103.6),
        moneyDropSpot = vector3(377.3, 333.5, 103.5),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    {
        id = 12,
        name = "Tool Store",
        zoneCenter = vector3(2748.0, 3472.0, 55.7),
        cashSpot = vector3(2747.7, 3472.0, 55.7),
        pedCoords = vector3(2748.0, 3472.0, 55.7),
        moneyDropSpot = vector3(2747.2, 3472.5, 55.6),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    {
        id = 13,
        name = "Tool Store Sandy",
        zoneCenter = vector3(2678.9, 3280.6, 55.2),
        cashSpot = vector3(2678.6, 3280.6, 55.2),
        pedCoords = vector3(2678.9, 3280.6, 55.2),
        moneyDropSpot = vector3(2678.1, 3281.1, 55.1),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    {
        id = 14,
        name = "Tool Store Paleto",
        zoneCenter = vector3(-110.5, 6469.6, 31.6),
        cashSpot = vector3(-110.2, 6469.6, 31.6),
        pedCoords = vector3(-110.5, 6469.6, 31.6),
        moneyDropSpot = vector3(-111.0, 6470.1, 31.5),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    },
    {
        id = 15,
        name = "Tool Store Grapeseed",
        zoneCenter = vector3(1707.9, 4920.5, 42.1),
        cashSpot = vector3(1707.6, 4920.5, 42.1),
        pedCoords = vector3(1707.9, 4920.5, 42.1),
        moneyDropSpot = vector3(1707.1, 4921.0, 42.0),
        pedModel = "mp_m_shopkeep_01",
        zoneRadius = 15.0
    }
}

-- Animation Settings
Config.Animations = {
    pedHandsUp = {dict = "random@mugging3", anim = "handsup_standing_base"},
    pedNormal = {dict = "amb@world_human_stand_guard@male@base", anim = "base"},
    dropMoney = {dict = "mp_common", anim = "givetake1_a"},
    pickupMoney = {dict = "pickup_object", anim = "pickup_low"}
}

-- Police Settings
Config.PoliceJobName = 'police'
Config.PoliceAlertTime = 120