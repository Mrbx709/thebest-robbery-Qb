local QBCore = exports['qb-core']:GetCoreObject()
local PlayerData = {}
local waitingAtRegister = false
local currentMarket = nil
local waitStartTime = 0
local waitThread = nil
local robberyActive = false
local pedHandsUp = false
local canTakeMoney = false
local zoneCheckThread = nil
local inMarketZone = false
local moneyObject = nil
local moneyDropped = false
local moneyPickupThread = nil

-- Initialize
CreateThread(function()
    while not QBCore do Wait(100) end
    PlayerData = QBCore.Functions.GetPlayerData()
    print('^2[thebest-robbery] Client script loaded with strict weapon check^0')
    
    if Config.TestMode then
        RegisterTestCommands()
    end
end)

-- Event Handlers
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    PlayerData = QBCore.Functions.GetPlayerData()
end)

RegisterNetEvent('QBCore:Client:OnJobUpdate', function(job)
    PlayerData.job = job
end)

-- STRICT WEAPON CHECK - MUST HAVE GUN
function HasWeapon()
    local playerPed = PlayerPedId()
    local _, currentWeapon = GetCurrentPedWeapon(playerPed, true)
    
    -- Check if armed at all
    if currentWeapon == `WEAPON_UNARMED` then
        return false, "You need a weapon to rob!"
    end
    
    -- Check weapon type
    local weaponType = GetWeaponDamageType(currentWeapon)
    
    -- Only allow guns (not melee, thrown, or other)
    -- Weapon damage types: 0=Unknown, 1=NoDamage, 2=Melee, 3=Bullet, 4=Force Ragdoll, 5=Explosive, 6=Fire, 7=Fall, 8=Electric, 9=Barbed Wire, 10=Run Over, 11=Helicopter Blade, 12=Exhaustion, 13=Drown, 14=Water Cannon
    if weaponType == 3 then -- 3 = Bullet (guns)
        return true, nil
    end
    
    return false, "You need a GUN to rob! (Pistol, SMG, Rifle, etc.)"
end

-- Find ped near cash register
function FindMarketPed(marketCoords)
    local playerPed = PlayerPedId()
    local nearestPed = nil
    local nearestDist = 3.0
    
    local handle, ped = FindFirstPed()
    repeat
        if DoesEntityExist(ped) and ped ~= playerPed and not IsPedAPlayer(ped) then
            local pedCoords = GetEntityCoords(ped)
            local dist = #(marketCoords - pedCoords)
            
            if dist < nearestDist then
                nearestPed = ped
                nearestDist = dist
            end
        end
        success, ped = FindNextPed(handle)
    until not success
    EndFindPed(handle)
    
    return nearestPed, nearestDist
end

-- Check if player is in market zone
function IsInMarketZone(market)
    local playerCoords = GetEntityCoords(PlayerPedId())
    local dist = #(playerCoords - market.zoneCenter)
    return dist <= market.zoneRadius
end

-- Make ped raise hands WHEN ROBBERY STARTS
function MakePedRaiseHands(ped)
    if not ped or not DoesEntityExist(ped) then return end
    
    pedHandsUp = true
    
    RequestAnimDict(Config.Animations.pedHandsUp.dict)
    while not HasAnimDictLoaded(Config.Animations.pedHandsUp.dict) do
        Wait(10)
    end
    
    -- Make ped face player first
    local playerPed = PlayerPedId()
    TaskTurnPedToFaceEntity(ped, playerPed, 1000)
    Wait(1000)
    
    -- Then raise hands
    TaskPlayAnim(ped, Config.Animations.pedHandsUp.dict, Config.Animations.pedHandsUp.anim, 
        8.0, 8.0, -1, 2, 0, false, false, false)
    
    print('^3[thebest-robbery] Ped raised hands^0')
end

-- Make ped normal (hands down) when robbery finishes
function MakePedNormal(ped)
    if not ped or not DoesEntityExist(ped) then return end
    
    pedHandsUp = false
    
    RequestAnimDict(Config.Animations.pedNormal.dict)
    while not HasAnimDictLoaded(Config.Animations.pedNormal.dict) do
        Wait(10)
    end
    
    TaskPlayAnim(ped, Config.Animations.pedNormal.dict, Config.Animations.pedNormal.anim, 
        8.0, 8.0, -1, 2, 0, false, false, false)
    
    print('^3[thebest-robbery] Ped hands down^0')
end

-- Cancel robbery
function CancelRobbery(reason)
    if not waitingAtRegister and not robberyActive and not moneyDropped then return end
    
    waitingAtRegister = false
    robberyActive = false
    canTakeMoney = false
    moneyDropped = false
    
    -- Remove money object
    if moneyObject then
        DeleteObject(moneyObject)
        moneyObject = nil
    end
    
    -- Reset current market ped
    if currentMarket then
        local market = Config.Markets[currentMarket]
        if market then
            local ped, _ = FindMarketPed(market.zoneCenter)
            if ped and DoesEntityExist(ped) then
                MakePedNormal(ped)
            end
        end
        currentMarket = nil
    end
    
    -- Stop threads
    if waitThread then
        waitThread = nil
    end
    
    if zoneCheckThread then
        zoneCheckThread = nil
    end
    
    if moneyPickupThread then
        moneyPickupThread = nil
    end
    
    -- Notify player
    if reason then
        QBCore.Functions.Notify(reason, "warning")
    end
    
    print('^3[thebest-robbery] Robbery cancelled^0')
end

-- Start zone check thread
function StartZoneCheck()
    if zoneCheckThread then return end
    
    zoneCheckThread = CreateThread(function()
        while waitingAtRegister or robberyActive do
            Wait(1000)
            
            local market = Config.Markets[currentMarket]
            if not market then
                CancelRobbery("Market not found")
                break
            end
            
            -- Check if player is still in zone
            if not IsInMarketZone(market) then
                CancelRobbery("Left market area - Robbery cancelled")
                TriggerServerEvent('thebest-robbery:cancelRobbery', currentMarket)
                break
            end
            
            -- STRICT: Check if player still has weapon
            local hasWeapon, weaponError = HasWeapon()
            if Config.RequireWeapon and not hasWeapon then
                CancelRobbery(weaponError)
                TriggerServerEvent('thebest-robbery:cancelRobbery', currentMarket)
                break
            end
        end
        zoneCheckThread = nil
    end)
end

-- Start waiting at market
function StartWaitingAtMarket(marketId)
    if waitingAtRegister or robberyActive or moneyDropped then 
        QBCore.Functions.Notify("Already robbing", "error")
        return 
    end
    
    local market = Config.Markets[marketId]
    if not market then return end
    
    -- STRICT: Check if player has weapon BEFORE starting
    local hasWeapon, weaponError = HasWeapon()
    if Config.RequireWeapon and not hasWeapon then
        QBCore.Functions.Notify(weaponError, "error")
        return
    end
    
    -- Check if player is in market zone
    if not IsInMarketZone(market) then
        QBCore.Functions.Notify("You must be inside the market", "error")
        return
    end
    
    waitingAtRegister = true
    currentMarket = marketId
    waitStartTime = GetGameTimer()
    inMarketZone = true
    
    -- Find and make ped raise hands IMMEDIATELY when robbery starts
    local ped, dist = FindMarketPed(market.zoneCenter)
    if ped then
        MakePedRaiseHands(ped)
    else
        QBCore.Functions.Notify("No cashier found", "error")
        CancelRobbery("No cashier")
        return
    end
    
    -- Start wait timer
    waitThread = CreateThread(function()
        local totalWait = Config.WaitTime * 1000
        
        while waitingAtRegister and inMarketZone do
            local elapsed = GetGameTimer() - waitStartTime
            local remaining = totalWait - elapsed
            
            if remaining <= 0 then
                -- Wait finished, can now drop money
                waitingAtRegister = false
                canTakeMoney = true
                
                QBCore.Functions.Notify("Robbery complete! Go to cash register and press ALT to drop money", "success")
                break
            end
            
            local secondsLeft = math.floor(remaining / 1000)
            DrawTextOnScreen("Robbery in progress: " .. secondsLeft .. " seconds - Stay in store!", 0.5, 0.9)
            
            Wait(0)
        end
    end)
    
    -- Start zone checking
    StartZoneCheck()
    
    -- Alert police
    TriggerServerEvent('thebest-robbery:alertPolice', market.zoneCenter, market.name)
    
    print('^3[thebest-robbery] Robbery started at ' .. market.name .. '^0')
end

-- Drop money on ground
function DropMoneyOnGround()
    if not canTakeMoney or not currentMarket then
        QBCore.Functions.Notify("Cannot drop money yet", "error")
        return
    end
    
    local market = Config.Markets[currentMarket]
    if not market then return end
    
    -- Check if still in zone
    if not IsInMarketZone(market) then
        QBCore.Functions.Notify("You must be inside the store to drop money", "error")
        return
    end
    
    robberyActive = true
    canTakeMoney = false
    
    -- Play drop money animation
    local playerPed = PlayerPedId()
    
    RequestAnimDict(Config.Animations.dropMoney.dict)
    while not HasAnimDictLoaded(Config.Animations.dropMoney.dict) do
        Wait(10)
    end
    
    TaskPlayAnim(playerPed, Config.Animations.dropMoney.dict, Config.Animations.dropMoney.anim, 
        8.0, 8.0, -1, 0, 0, false, false, false)
    Wait(1000)
    
    -- Create money object on ground
    CreateMoneyOnGround(market.moneyDropSpot)
    
    -- Reset ped to normal (hands down) when money drops
    local ped, _ = FindMarketPed(market.zoneCenter)
    if ped and DoesEntityExist(ped) then
        MakePedNormal(ped)
    end
    
    -- Mark as dropped
    moneyDropped = true
    robberyActive = false
    
    if waitThread then
        waitThread = nil
    end
    
    if zoneCheckThread then
        zoneCheckThread = nil
    end
    
    QBCore.Functions.Notify("Money dropped on ground! Walk to it and press E to pick up $4500", "success")
    
    print('^3[thebest-robbery] Money dropped at ' .. market.name .. '^0')
end

-- Create money object on ground
function CreateMoneyOnGround(coords)
    if moneyObject then
        DeleteObject(moneyObject)
    end
    
    RequestModel(GetHashKey(Config.MoneyModel))
    while not HasModelLoaded(GetHashKey(Config.MoneyModel)) do
        Wait(10)
    end
    
    moneyObject = CreateObject(GetHashKey(Config.MoneyModel), 
        coords.x, coords.y, coords.z, 
        true, true, true)
    
    SetEntityAsMissionEntity(moneyObject, true, true)
    PlaceObjectOnGroundProperly(moneyObject)
    FreezeEntityPosition(moneyObject, true)
    
    -- Start pickup thread
    StartMoneyPickupThread()
    
    print('^3[thebest-robbery] Money object created^0')
end

-- Start money pickup thread
function StartMoneyPickupThread()
    if moneyPickupThread then return end
    
    moneyPickupThread = CreateThread(function()
        while moneyObject and DoesEntityExist(moneyObject) do
            Wait(0)
            
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local moneyCoords = GetEntityCoords(moneyObject)
            local dist = #(playerCoords - moneyCoords)
            
            -- Draw text above money
            DrawText3D(moneyCoords.x, moneyCoords.y, moneyCoords.z + 0.5, 
                "Press [E] to pickup $4500")
            
            if dist < Config.MoneyPickupDistance then
                if IsControlJustPressed(0, Config.MoneyPickupKey) then -- E key
                    PickupMoney()
                    break
                end
            end
        end
        moneyPickupThread = nil
    end)
end

-- Pickup money from ground
function PickupMoney()
    if not moneyObject then return end
    
    -- Play pickup animation
    local playerPed = PlayerPedId()
    
    RequestAnimDict(Config.Animations.pickupMoney.dict)
    while not HasAnimDictLoaded(Config.Animations.pickupMoney.dict) do
        Wait(10)
    end
    
    TaskPlayAnim(playerPed, Config.Animations.pickupMoney.dict, Config.Animations.pickupMoney.anim, 
        8.0, 8.0, -1, 0, 0, false, false, false)
    Wait(1000)
    
    -- Remove money object
    DeleteObject(moneyObject)
    moneyObject = nil
    
    -- Give money to player via server
    TriggerServerEvent('thebest-robbery:giveMoney', currentMarket)
    
    -- Reset
    moneyDropped = false
    currentMarket = nil
    
    if moneyPickupThread then
        moneyPickupThread = nil
    end
    
    print('^3[thebest-robbery] Money picked up^0')
end

-- Draw screen text
function DrawTextOnScreen(text, x, y)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(x, y)
end

-- Draw 3D text
function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end

-- Main interaction thread
CreateThread(function()
    while true do
        Wait(0)
        
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        
        -- Check all markets
        for i, market in ipairs(Config.Markets) do
            local distToCashSpot = #(playerCoords - market.cashSpot)
            
            if distToCashSpot < Config.InteractionDistance then
                -- Player is at cash spot
                if not waitingAtRegister and not robberyActive and not moneyDropped then
                    -- STRICT: Check weapon BEFORE showing prompt
                    local hasWeapon, weaponError = HasWeapon()
                    
                    if Config.RequireWeapon and not hasWeapon then
                        -- Show "NEED WEAPON" message
                        DrawText3D(market.cashSpot.x, market.cashSpot.y, market.cashSpot.z + 0.5, 
                            weaponError)
                    else
                        -- Show "PRESS ALT" message
                        DrawText3D(market.cashSpot.x, market.cashSpot.y, market.cashSpot.z + 0.5, 
                            "Press [ALT] to start robbery (2 minutes)")
                        
                        if IsControlJustPressed(0, Config.InteractionKey) then
                            TriggerServerEvent('thebest-robbery:startRobbery', i)
                        end
                    end
                    
                elseif waitingAtRegister and currentMarket == i then
                    -- Currently robbing
                    local elapsed = GetGameTimer() - waitStartTime
                    local secondsLeft = Config.WaitTime - math.floor(elapsed / 1000)
                    
                    if secondsLeft > 0 then
                        DrawText3D(market.cashSpot.x, market.cashSpot.y, market.cashSpot.z + 0.5, 
                            "Robbery in progress: " .. secondsLeft .. "s - Stay in store!")
                    end
                    
                elseif canTakeMoney and currentMarket == i then
                    -- Can drop money
                    DrawText3D(market.cashSpot.x, market.cashSpot.y, market.cashSpot.z + 0.5, 
                        "Press [ALT] to drop money on ground")
                    
                    if IsControlJustPressed(0, Config.InteractionKey) then
                        DropMoneyOnGround()
                    end
                end
                
                break
            end
        end
    end
end)

-- Register test commands
function RegisterTestCommands()
    if Config.TestMode then
        RegisterCommand('testrobbery', function()
            print('^2=== THEBEST ROBBERY TEST ===^0')
            print('Waiting: ' .. tostring(waitingAtRegister))
            print('Current Market: ' .. tostring(currentMarket))
            print('Can Drop Money: ' .. tostring(canTakeMoney))
            print('Money Dropped: ' .. tostring(moneyDropped))
            print('Has Money Object: ' .. tostring(moneyObject ~= nil))
            print('Robbery Active: ' .. tostring(robberyActive))
            print('Ped Hands Up: ' .. tostring(pedHandsUp))
            
            local hasWeapon, weaponError = HasWeapon()
            print('Has Weapon: ' .. tostring(hasWeapon))
            print('Weapon Error: ' .. tostring(weaponError))
            
            print('Total Markets: ' .. #Config.Markets)
        end, false)
        
        RegisterCommand('skipwait', function()
            if waitingAtRegister then
                waitingAtRegister = false
                canTakeMoney = true
                QBCore.Functions.Notify("Wait skipped - Can now drop money", "success")
            end
        end, false)
        
        RegisterCommand('dropmoney', function()
            if canTakeMoney then
                DropMoneyOnGround()
            end
        end, false)
        
        RegisterCommand('forcemoney', function()
            local market = Config.Markets[1]
            if market then
                CreateMoneyOnGround(market.moneyDropSpot)
                moneyDropped = true
                QBCore.Functions.Notify("Money forced on ground", "success")
            end
        end, false)
        
        RegisterCommand('pickupmoney', function()
            if moneyObject then
                PickupMoney()
            end
        end, false)
        
        RegisterCommand('clearmoney', function()
            if moneyObject then
                DeleteObject(moneyObject)
                moneyObject = nil
                moneyDropped = false
                QBCore.Functions.Notify("Money cleared", "warning")
            end
        end, false)
        
        RegisterCommand('tpmarket', function(args)
            local marketId = tonumber(args[1]) or 1
            local market = Config.Markets[marketId]
            if market then
                SetEntityCoords(PlayerPedId(), market.cashSpot.x, market.cashSpot.y, market.cashSpot.z)
                QBCore.Functions.Notify("Teleported to " .. market.name, "success")
            end
        end, false)
        
        RegisterCommand('tpmoney', function(args)
            local marketId = tonumber(args[1]) or 1
            local market = Config.Markets[marketId]
            if market then
                SetEntityCoords(PlayerPedId(), market.moneyDropSpot.x, market.moneyDropSpot.y, market.moneyDropSpot.z)
                QBCore.Functions.Notify("Teleported to money drop spot", "success")
            end
        end, false)
        
        RegisterCommand('cancelrob', function()
            CancelRobbery("Manually cancelled")
        end, false)
        
        RegisterCommand('checkweapon', function()
            local playerPed = PlayerPedId()
            local _, weapon = GetCurrentPedWeapon(playerPed, true)
            local hasWeapon, weaponError = HasWeapon()
            
            print('^2=== WEAPON CHECK ===^0')
            print('Weapon Hash: ' .. weapon)
            print('Weapon Name: ' .. GetWeaponNameFromHash(weapon))
            print('Has Weapon (Script): ' .. tostring(hasWeapon))
            print('Weapon Error: ' .. tostring(weaponError))
            print('Is Unarmed: ' .. tostring(weapon == `WEAPON_UNARMED`))
            
            -- Show current weapon in game
            local weaponName = GetWeaponNameFromHash(weapon)
            QBCore.Functions.Notify("Current Weapon: " .. weaponName, "info")
        end, false)
        
        RegisterCommand('listmarkets', function()
            print('^2=== ALL 15 MARKETS ===^0')
            for i, market in ipairs(Config.Markets) do
                print(i .. '. ' .. market.name)
                print('   Cash Spot: ' .. tostring(market.cashSpot))
                print('   Money Drop: ' .. tostring(market.moneyDropSpot))
            end
        end, false)
        
        RegisterCommand('testnoweapon', function()
            -- Test without weapon
            local playerPed = PlayerPedId()
            SetCurrentPedWeapon(playerPed, `WEAPON_UNARMED`, true)
            QBCore.Functions.Notify("Weapon removed - Try robbing now", "warning")
        end, false)
        
        RegisterCommand('testwithweapon', function()
            -- Test with weapon
            local playerPed = PlayerPedId()
            GiveWeaponToPed(playerPed, `WEAPON_PISTOL`, 250, false, true)
            SetCurrentPedWeapon(playerPed, `WEAPON_PISTOL`, true)
            QBCore.Functions.Notify("Pistol given - Try robbing now", "success")
        end, false)
    end
end

-- Server Events
RegisterNetEvent('thebest-robbery:startClientRobbery')
AddEventHandler('thebest-robbery:startClientRobbery', function(marketId)
    if not waitingAtRegister and not robberyActive and not moneyDropped then
        StartWaitingAtMarket(marketId)
    end
end)

RegisterNetEvent('thebest-robbery:notify')
AddEventHandler('thebest-robbery:notify', function(message, type)
    QBCore.Functions.Notify(message, type or "primary")
end)

RegisterNetEvent('thebest-robbery:policeAlert')
AddEventHandler('thebest-robbery:policeAlert', function(coords, storeName)
    local PlayerData = QBCore.Functions.GetPlayerData()
    
    if PlayerData.job and PlayerData.job.name == Config.PoliceJobName then
        QBCore.Functions.Notify("Store Robbery: " .. storeName, "police")
        
        local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
        SetBlipSprite(blip, 487)
        SetBlipColour(blip, 1)
        SetBlipDisplay(blip, 4)
        SetBlipScale(blip, 1.2)
        SetBlipAsShortRange(blip, false)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("ROBBERY: " .. storeName)
        EndTextCommandSetBlipName(blip)
        SetBlipFlashes(blip, true)
        
        CreateThread(function()
            Wait(Config.PoliceAlertTime * 1000)
            RemoveBlip(blip)
        end)
    end
end)

RegisterNetEvent('thebest-robbery:moneyReceived')
AddEventHandler('thebest-robbery:moneyReceived', function(amount)
    QBCore.Functions.Notify("You picked up $" .. amount .. " cash!", "success")
end)

-- Cleanup
AddEventHandler('onResourceStop', function(resource)
    if GetCurrentResourceName() == resource then
        CancelRobbery("Resource stopped")
    end
end)