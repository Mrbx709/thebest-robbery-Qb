fx_version 'cerulean'
game 'gta5'

author 'TheBest-Robbery'
description 'TheBest Robbery - Strict Weapon Requirement System'
version '1.0.0'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

dependencies {
    'qb-core'
}